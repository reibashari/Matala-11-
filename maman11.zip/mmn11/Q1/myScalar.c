#include <stdio.h> 

/*
The program receives 2 vectors and a vector size, and makes it a scalar product
*/

int main() 
{ 
	int size, sum , i ; 
	  
	
	printf("Hi , please enter the size of the vectors \n") ;
	scanf("%d" , &size) ; /*we get from the user the size of the vectors*/ 

	int vt1[size] , vt2[size] ;

	printf("great! , now please enter the first vector: \n");
	for (i=0 ; i< size	; i++)
		scanf("%d" , &vt1[i]) ; 

	printf("Fantastic! , now enter the second vector: \n");
	for (i=0 ; i< size	; i++)
		scanf("%d" , &vt2[i]) ;
	
	for (i= 0 ; i < size ; i++) /* the scalar product */
		sum += vt1[i]*vt2[i] ; 
	
	printf("The result of the multiplication of two vectors is: %d\n" , sum)  ; 

	return 0; 
}


